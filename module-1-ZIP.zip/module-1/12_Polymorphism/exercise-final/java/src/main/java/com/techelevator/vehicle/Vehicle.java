package com.techelevator.vehicle;

public interface Vehicle {

	double calculateToll(int distance);

	String getType();

}
