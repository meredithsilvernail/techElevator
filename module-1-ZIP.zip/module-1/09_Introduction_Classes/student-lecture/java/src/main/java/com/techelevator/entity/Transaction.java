package com.techelevator.entity;

public class Transaction {
}
