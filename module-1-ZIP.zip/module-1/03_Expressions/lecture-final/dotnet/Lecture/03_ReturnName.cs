﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lecture
{
    public partial class LectureExample
    {
        /*
        3. This method needs to return a string. Null represents no value.
            Fix it to return a valid string.
            TOPIC: Return Values
        */
        public string ReturnName()
        {
            return "Josh";
        }

    }
}
