﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lecture
{
    public partial class LectureExample
    {
        /*
        2. This method is named ReturnNotHalf and it returns a double. 
            Change it so that it returns something other than a 0.5.
            TOPIC: Return Values
        */
        public double ReturnNotHalf()
        {
            return 1.5;
        }
    }
}
