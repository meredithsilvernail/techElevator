﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lecture
{
    public partial class LectureExample
    {
        /*
        5. This method should return the language that you're learning (C#). 
            Change the code so it does that.
            TOPIC: Return Types
        */
        public bool ReturnNameOfLanguage()
        {
            return false;
        }
    }
}
