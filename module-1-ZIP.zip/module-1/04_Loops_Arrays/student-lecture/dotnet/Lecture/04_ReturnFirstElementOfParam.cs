﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lecture
{
    public partial class LectureProblem
    {

        /*
        4. Return the first element of the array from the parameters
            TOPIC: Accessing Array Elements
        */
        public int ReturnFirstElementOfParam(int[] passedInArray)
        {
            return 1;
        }

        /*
        4b. Set the first element in the array to 100.     
            TOPIC: Setting Array Elements
        */
        public void SetFirstElement(int[] passedInArray)
        {            
            return;
        }
    }
}
