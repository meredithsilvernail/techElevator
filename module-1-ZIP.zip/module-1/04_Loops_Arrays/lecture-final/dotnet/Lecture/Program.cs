﻿using System;

namespace Lecture
{
    class Program
    {
        static void Main(string[] args)
        {
               //1. Use a for-loop to print "Hello World" 10 times




        }
    }
}
