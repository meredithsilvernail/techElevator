﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises
{
    public partial class Exercises
    {
        /*
         Return an int array length 3 containing the first 3 digits of pi, {3, 1, 4}.
         MakePi() → [3, 1, 4]
         */
        public int[] MakePi()
        {
            return new int[] { 3, 1, 4 };
        }

    }
}
