package com.techelevator.client;

import com.techelevator.domain.Customer;

public class Driver {

    public static void main(String[] args) {

        Customer customer1 = new Customer();

    }
}
